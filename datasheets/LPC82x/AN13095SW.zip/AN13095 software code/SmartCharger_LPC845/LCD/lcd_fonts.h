
/*
 * Copyright (c) 2017 - 2018 , NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef _USE_FONTS_H
#define _USE_FONTS_H


#include "stdint.h"

extern const uint8_t c_chFont1206[95][12];
extern const uint8_t c_chFont1608[95][16];

#endif

/*-------------------------------END OF FILE-------------------------------*/

