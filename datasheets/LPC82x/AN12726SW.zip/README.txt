/*

${ProjName}:
SCT_UART


Intended purpose:
* To demostrate the configuration and use of the SCT to emulate UART.



Functional description :
 * The UART is emulated by SCT.(It is stable when the baud rate is below 115200 and the chip runs at 30MHz)
 * You can change the UART parameters by modifying the macro(such as SCT_UART_BAUD_RATE etc, please refer to the relevant comments).



Pins used in this example:
 * P0.4  [Input]  - RX
 * P0.0  [Output]  - TX
 * Note：You can change the RX pin and TX pin through macros.



Detailed Program Flow:
* This example runs at 30 MHz (PLL, running from IRC, generating 60 MHz, divided by 2).
  See funtion SystemInit() in the startup code.

* Steps:
   1. Change the UART parameters by modifying the macro(such as SCT_UART_BAUD_RATE etc, please refer to the relevant comments).
      The default parameter are baud rate 115200, data bits 9, stop bits 1, no parity.
   2. Please implement SCT_UART_Receive_Byte_CallBack() according to your needs(Please refer to the relevant comments).
   3. Use SCT_UART_Init() to complete the initialization.
   4. Now, you can use SCT_UART_Send_Byte() to send data, and process received data in SCT_UART_Receive_Byte_CallBack().


 
This example runs from Flash. To run this code: 

* Build, Debug, Run or Go
  or
* Download to flash, Reset


                                

*/